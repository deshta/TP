package software.civíl;
public class Contato
{
    String nome;
    String email;
    private int codigoContato;
    private String tipo;
    
    public Contato()
    {
        codigoContato = 0;
        tipo = null;
    }
    
    public Contato(int codigoContato, String tipo)
    {
        this.codigoContato = codigoContato;
        this.tipo = tipo;
    }
    
    
    public void setCodigoContato(int codigoContato)
    {
        this.codigoContato = codigoContato;
    }
    
    public void setTipo(String tipo)
    {
        this.tipo = tipo;
    }
    
    /*---------------------------------------------------*/
    
    public int getCodigoContato( )
    {
        return codigoContato;
    }
    
    public String getArquivo( )
    {
        return tipo;
    }
}
